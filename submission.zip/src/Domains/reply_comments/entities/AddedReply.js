
class AddedReply {
  constructor(payload) {
    this._verifypayload(payload);
    const {id, owner, content} = payload;
    this.id = id;
    this.owner = owner;
    this.content = content;
  }

  _verifypayload({id, owner, content}) {
    if (!id || !owner || !content) {
      throw new Error('ADDED_REPLY.NOT_CONTAIN_NEEDED_PROPERTY');
    }

    if (typeof id !== 'string' || typeof owner !== 'string' || typeof content !== 'string') {
      throw new Error('ADDED_REPLY.NOT_MEET_DATA_TYPE_SPECIFICATION');
    }
  }
}

module.exports = AddedReply;
